package com.threed.peintures;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;

    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        webView=new WebView(this);
        setContentView(webView);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new PdfBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private static String money(double v){
        return String.format(Locale.FRANCE, "%,.2f DH", v).replace('\u00a0',' ');
    }

    private static void text(Canvas c, Paint p, String s, float x, float y){
        c.drawText(s == null ? "" : s, x, y, p);
    }

    private class PdfBridge {
        @JavascriptInterface
        public void createOrderPdf(String json){
            try {
                JSONObject o=new JSONObject(json);
                File dir=new File(getExternalFilesDir(null), "bons");
                if(!dir.exists()) dir.mkdirs();
                String safe=o.optString("client","client").replaceAll("[^A-Za-z0-9_-]+","_");
                String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
                File file=new File(dir,"Bon_Commande_"+safe+"_"+stamp+".pdf");

                PdfDocument doc=new PdfDocument();
                int pageNo=1;
                PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());
                Canvas c=page.getCanvas();
                Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
                p.setTextSize(11);

                float left=38, right=557, y=42;
                p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
                p.setTextSize(11); p.setLetterSpacing(.18f);
                p.setColor(0xffb58a2a); text(c,p,"3D PEINTURES",left,y);
                p.setLetterSpacing(0);
                p.setColor(0xff12386f); p.setTextSize(25); text(c,p,"BON DE COMMANDE",left,y+35);
                p.setColor(0xff667085); p.setTextSize(10);
                String ref=o.optString("id","");
                String iso=o.optString("date","");
                Date parsed=new Date();
                try { if(!iso.isEmpty()) parsed=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Locale.US).parse(iso); } catch(Exception ignored) {}
                String date=new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.FRANCE).format(parsed);
                text(c,p,date,left,y+55);

                y+=85;
                p.setColor(0xfff4f6fa); c.drawRoundRect(left,y,right,y+82,10,10,p);
                p.setColor(0xff667085); p.setTextSize(9); p.setTypeface(Typeface.DEFAULT_BOLD);
                text(c,p,"CLIENT",left+14,y+20);
                p.setColor(0xff172033); p.setTextSize(16); p.setTypeface(Typeface.DEFAULT_BOLD);
                text(c,p,o.optString("client",""),left+14,y+43);
                p.setTypeface(Typeface.DEFAULT); p.setTextSize(10);
                float infoY=y+61;
                String company=o.optString("company","");
                String ice=o.optString("ice","");
                String phone=o.optString("phone","");
                String whatsapp=o.optString("whatsapp",phone);
                String info=(company.isEmpty()?"":("Société : "+company))+
                        (ice.isEmpty()?"":("   |   ICE : "+ice))+
                        (phone.isEmpty()?"":("   |   Tél. : "+phone));
                text(c,p,info,left+14,infoY);

                y+=105;
                // Table header
                float[] col={left,300,350,425,490,right};
                p.setColor(0xff12386f); c.drawRect(left,y,right,y+28,p);
                p.setColor(0xffffffff); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(9);
                text(c,p,"Désignation",col[0]+7,y+18);
                text(c,p,"Boîtes",col[1]+7,y+18);
                text(c,p,"Unités",col[2]+7,y+18);
                text(c,p,"Prix",col[3]+7,y+18);
                text(c,p,"Total",col[4]+7,y+18);
                y+=28;

                JSONArray items=o.optJSONArray("items");
                p.setTypeface(Typeface.DEFAULT); p.setTextSize(9);
                double total=o.optDouble("total",0);
                if(items!=null){
                    for(int i=0;i<items.length();i++){
                        JSONObject it=items.getJSONObject(i);
                        if(y>720){
                            doc.finishPage(page);
                            pageNo++;
                            page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());
                            c=page.getCanvas(); y=50;
                        }
                        p.setColor(i%2==0?0xffffffff:0xfff7f8fa);
                        c.drawRect(left,y,right,y+30,p);
                        p.setColor(0xff172033);
                        String name=it.optString("name","");
                        if(name.length()>39) name=name.substring(0,36)+"...";
                        text(c,p,name,col[0]+7,y+19);
                        text(c,p,String.valueOf(it.optInt("boxes",0)),col[1]+10,y+19);
                        text(c,p,String.valueOf(it.optInt("units",0)),col[2]+10,y+19);
                        text(c,p,money(it.optDouble("unitPrice",0)),col[3]+3,y+19);
                        text(c,p,money(it.optDouble("lineTotal",0)),col[4]+3,y+19);
                        p.setColor(0xffdddddd); c.drawRect(left,y+29,right,y+30,p);
                        y+=30;
                    }
                }

                if(y>675){
                    doc.finishPage(page);
                    pageNo++;
                    page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());
                    c=page.getCanvas(); y=50;
                }
                y+=22;
                p.setColor(0xff12386f); c.drawRoundRect(330,y,557,y+58,10,10,p);
                p.setColor(0xffffffff); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(15);
                text(c,p,"Total Payé",348,y+34); text(c,p,money(total),470,y+34);

                y+=85;
                // Mention de paiement à la livraison : grande, centrée et rouge.
                p.setColor(0xffff0000);
                p.setTypeface(Typeface.DEFAULT_BOLD);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(22);
                c.drawText("إستخلاص عند الاستلام", (left+right)/2f, y+18, p);
                p.setTextSize(18);
                c.drawText("Paiement à la livraison", (left+right)/2f, y+48, p);
                p.setTextAlign(Paint.Align.LEFT);
                if(!o.optString("note","").isEmpty() && !o.optString("note").contains("Paiement à la livraison")) {
                    p.setColor(0xff667085); p.setTextSize(8); p.setTypeface(Typeface.DEFAULT);
                    text(c,p,"Note : "+o.optString("note"),left+14,y+72);
                }
                text(c,p,"Merci pour votre confiance • 3D PEINTURES",left,810);

                doc.finishPage(page);
                FileOutputStream out=new FileOutputStream(file);
                doc.writeTo(out); out.close(); doc.close();

                Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",file);
                Intent send=new Intent(Intent.ACTION_SEND);
                send.setType("application/pdf");
                send.putExtra(Intent.EXTRA_STREAM,uri);
                send.putExtra(Intent.EXTRA_SUBJECT,"Bon de commande - "+o.optString("client",""));
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                // Ouvre directement la conversation WhatsApp du client lorsqu'un numéro est enregistré.
                String wa=whatsapp==null?"":whatsapp.replaceAll("[^0-9]","");
                if(wa.startsWith("0")) wa="212"+wa.substring(1);
                if(wa.startsWith("212") && wa.length()>=12){
                    send.putExtra("jid",wa+"@s.whatsapp.net");
                }
                try {
                    getPackageManager().getPackageInfo("com.whatsapp",0);
                    send.setPackage("com.whatsapp");
                    startActivity(send);
                } catch(Exception noWhatsapp) {
                    try {
                        getPackageManager().getPackageInfo("com.whatsapp.w4b",0);
                        send.setPackage("com.whatsapp.w4b");
                        startActivity(send);
                    } catch(Exception noBusinessWhatsapp) {
                        Intent chooser=Intent.createChooser(send,"Envoyer le Bon de commande");
                        startActivity(chooser);
                    }
                }
            } catch(Exception e){
                e.printStackTrace();
                runOnUiThread(()->webView.evaluateJavascript("toast("+JSONObject.quote("Erreur PDF : "+e.getMessage())+")",null));
            }
        }
    }

    @Override public void onBackPressed(){
        if(webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
