3D PEINTURES — version avec Bon de commande PDF

Modification demandée :
- Le texte « إستخلاص عند الاستلام » est affiché en GRAND, au CENTRE et en ROUGE dans le Bon de commande PDF.
- « Paiement à la livraison » est également affiché en GRAND, au CENTRE et en ROUGE juste dessous.
- La modification est appliquée au PDF Android natif et au PDF Web de secours.

Pour Android : ouvrir le dossier android dans Android Studio puis générer l'APK.
